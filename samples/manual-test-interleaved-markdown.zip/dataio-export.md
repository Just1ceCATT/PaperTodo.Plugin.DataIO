<!-- papertodo-dataio:v2 type=note sourceId=manualtest-note-interleaved -->
# 手动测试：图文穿插

第一段文字：下面是第一张图片（100% 宽度）。

![image|100%](images/manualtest-note-interleaved/101.png)

第二段文字：图片和文字应该按原顺序交错出现。

![image|50%](images/manualtest-note-interleaved/102.png)

第三段文字：这是结尾，用来确认后续文字没有被图片块吞掉。

---

<!-- papertodo-dataio:v2 type=todo sourceId=manualtest-todo -->
# 手动测试：待办

- [ ] 检查更新预览是否列出图片变化
- [x] 完成一次 JSON 压缩包导入
- [ ] 再次导入并确认“无变化”提示